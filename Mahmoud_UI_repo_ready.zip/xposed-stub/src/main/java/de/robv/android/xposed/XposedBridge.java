package de.robv.android.xposed;

/** Compile-time stub of the Xposed API. */
public final class XposedBridge {
    private XposedBridge() { }

    public static void log(String text) { }

    public static void log(Throwable t) { }
}
