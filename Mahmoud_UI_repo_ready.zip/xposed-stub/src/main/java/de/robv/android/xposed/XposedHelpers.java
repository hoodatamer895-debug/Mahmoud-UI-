package de.robv.android.xposed;

/** Compile-time stub of the Xposed API. */
public final class XposedHelpers {
    private XposedHelpers() { }

    public static Class<?> findClass(String className, ClassLoader classLoader) {
        throw new UnsupportedOperationException("stub");
    }

    public static XC_MethodHook.Unhook findAndHookMethod(Class<?> clazz, String methodName,
                                                         Object... parameterTypesAndCallback) {
        throw new UnsupportedOperationException("stub");
    }

    public static float getFloatField(Object obj, String fieldName) {
        throw new UnsupportedOperationException("stub");
    }

    public static void setFloatField(Object obj, String fieldName, float value) {
        throw new UnsupportedOperationException("stub");
    }

    public static Object callStaticMethod(Class<?> clazz, String methodName, Object... args) {
        throw new UnsupportedOperationException("stub");
    }
}
