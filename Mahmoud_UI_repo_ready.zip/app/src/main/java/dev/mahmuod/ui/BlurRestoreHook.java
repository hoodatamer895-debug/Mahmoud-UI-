package dev.mahmuod.ui;

import android.app.Application;
import android.provider.Settings;
import android.os.SystemClock;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

/** Fixed, narrow adjustment: soften only Samsung Quick Settings blur radius. */
public final class BlurRestoreHook implements IXposedHookLoadPackage {
    private static final String TAG = "MahmuodUI-BlurRestore";
    // Lower radius means less dense blur; do not alter tint, alpha, dim, or layout.
    private static final String SETTING_KEY = "mahmuod_ui_blur_strength_v2";
    private static final int DEFAULT_STRENGTH = 20;
    private static volatile int cachedStrength = DEFAULT_STRENGTH;
    private static volatile long lastReadAt;

    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lpparam) {
        if (!"com.android.systemui".equals(lpparam.packageName)) return;
        try {
            Class<?> curve = XposedHelpers.findClass(
                    "com.android.systemui.blur.QSColorCurve", lpparam.classLoader);
            XposedHelpers.findAndHookMethod(curve, "setFraction", float.class,
                    new XC_MethodHook() {
                        @Override
                        protected void afterHookedMethod(MethodHookParam param) {
                            try {
                                int strength = readStrength();
                                float radius = XposedHelpers.getFloatField(param.thisObject, "radius");
                                if (Float.isNaN(radius) || Float.isInfinite(radius) || radius <= 0f) return;
                                XposedHelpers.setFloatField(param.thisObject, "radius", radius * (strength / 100f));
                            } catch (Throwable error) {
                                XposedBridge.log(TAG + ": could not adjust blur radius: " + error);
                            }
                        }
                    });
            XposedBridge.log(TAG + ": adjustable stock QS blur radius hook installed");
        } catch (Throwable error) {
            // Fail closed: if this SystemUI build differs, leave the stock UI untouched.
            XposedBridge.log(TAG + ": hook unavailable; stock SystemUI left unchanged: " + error);
        }
    }

    private static int readStrength() {
        long now = SystemClock.uptimeMillis();
        if (now - lastReadAt < 250L) return cachedStrength;
        synchronized (BlurRestoreHook.class) {
            if (now - lastReadAt >= 250L) {
                try {
                    Application app = (Application) XposedHelpers.callStaticMethod(
                            XposedHelpers.findClass("android.app.ActivityThread", null),
                            "currentApplication");
                    if (app != null) {
                        cachedStrength = Settings.System.getInt(app.getContentResolver(),
                                SETTING_KEY, DEFAULT_STRENGTH);
                        cachedStrength = Math.max(1, Math.min(100, cachedStrength));
                    }
                } catch (Throwable error) {
                    XposedBridge.log(TAG + ": cannot read strength; keeping cached value: " + error);
                }
                lastReadAt = now;
            }
        }
        return cachedStrength;
    }
}
