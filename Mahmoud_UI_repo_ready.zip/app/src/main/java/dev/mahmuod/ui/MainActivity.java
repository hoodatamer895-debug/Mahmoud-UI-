package dev.mahmuod.ui;

import android.app.Activity;
import android.content.res.ColorStateList;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.ClipDrawable;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.LayerDrawable;
import android.graphics.drawable.RippleDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.style.RelativeSizeSpan;
import android.view.Gravity;
import android.view.HapticFeedbackConstants;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Mahmoud UI settings screen, styled after Samsung One UI 9:
 * large title header, rounded grouped cards, a thick pill slider with a white handle,
 * a big counter with round +/- steppers, and pill presets. Follows the system dark/light mode.
 */
public final class MainActivity extends Activity {
    private static final String KEY = "mahmuod_ui_blur_strength_v2";
    private static final int DEFAULT_STRENGTH = 20;
    private static final int SYSTEM_STRENGTH = 100;
    private static final int MAX_STRENGTH = 100;

    private static final int STATUS_IDLE = 0;
    private static final int STATUS_BUSY = 1;
    private static final int STATUS_OK = 2;
    private static final int STATUS_ERROR = 3;

    private TextView valueLabel;
    private TextView statusText;
    private View statusDot;
    private SeekBar strengthBar;
    private final TextView[] chips = new TextView[3];
    private final boolean[] chipSelected = new boolean[3];
    private final int[] chipValues = {20, 50, MAX_STRENGTH};

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final ExecutorService saver = Executors.newSingleThreadExecutor();
    private int pendingValue = DEFAULT_STRENGTH;
    private final Runnable persistRunnable = () -> persist(pendingValue);

    // One UI palette (filled by initPalette)
    private boolean dark;
    private int bg, card, textPrimary, textSecondary, accent, accentSoft, track, chipBg, divider;
    private int green, red;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        initPalette();
        setupWindow();
        buildUi();
        applySystemBarAppearance();
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshValue();
    }

    @Override
    protected void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        super.onDestroy();
    }

    // ------------------------------------------------------------------ theme

    private void initPalette() {
        int mode = getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK;
        dark = mode == Configuration.UI_MODE_NIGHT_YES;
        accent = 0xFF3E91FF;
        if (dark) {
            bg = 0xFF000000;
            card = 0xFF1F1F1F;
            textPrimary = 0xFFFFFFFF;
            textSecondary = 0xFFA8A8A8;
            accentSoft = 0xFF1B3556;
            track = 0xFF3A3A3A;
            chipBg = 0xFF2E2E2E;
            divider = 0xFF303030;
            green = 0xFF30D158;
            red = 0xFFFF453A;
        } else {
            bg = 0xFFF6F6F6;
            card = 0xFFFFFFFF;
            textPrimary = 0xFF111111;
            textSecondary = 0xFF707070;
            accentSoft = 0xFFDDEBFF;
            track = 0xFFE3E3E3;
            chipBg = 0xFFF0F0F0;
            divider = 0xFFEDEDED;
            green = 0xFF2DB84D;
            red = 0xFFE5322D;
        }
    }

    @SuppressWarnings("deprecation")
    private void setupWindow() {
        Window w = getWindow();
        w.setBackgroundDrawable(new ColorDrawable(bg));
        if (Build.VERSION.SDK_INT >= 30) {
            w.setDecorFitsSystemWindows(false);
        } else {
            int flags = View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                    | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION;
            if (!dark) {
                flags |= View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
                if (Build.VERSION.SDK_INT >= 26) flags |= View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
            }
            w.getDecorView().setSystemUiVisibility(flags);
        }
        w.setStatusBarColor(Color.TRANSPARENT);
        w.setNavigationBarColor(Color.TRANSPARENT);
        if (Build.VERSION.SDK_INT >= 29) w.setNavigationBarContrastEnforced(false);
    }

    private void applySystemBarAppearance() {
        if (Build.VERSION.SDK_INT < 30) return;
        WindowInsetsController controller = getWindow().getInsetsController();
        if (controller == null) return;
        int mask = WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS
                | WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS;
        controller.setSystemBarsAppearance(dark ? 0 : mask, mask);
    }

    // --------------------------------------------------------------------- UI

    @SuppressWarnings("deprecation")
    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setVerticalScrollBarEnabled(false);
        scroll.setBackgroundColor(bg);

        final LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        content.setPadding(dp(20), 0, dp(20), dp(24));
        scroll.addView(content, new ScrollView.LayoutParams(
                ScrollView.LayoutParams.MATCH_PARENT, ScrollView.LayoutParams.WRAP_CONTENT));

        scroll.setOnApplyWindowInsetsListener((v, insets) -> {
            content.setPadding(dp(20) + insets.getSystemWindowInsetLeft(),
                    insets.getSystemWindowInsetTop(),
                    dp(20) + insets.getSystemWindowInsetRight(),
                    dp(24) + insets.getSystemWindowInsetBottom());
            return insets;
        });

        // ---- large title header (One UI style: big empty area, title sits at the bottom)
        int screenH = getResources().getDisplayMetrics().heightPixels;
        int headerH = Math.max(dp(190), Math.round(screenH * 0.25f));
        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.VERTICAL);
        header.setGravity(Gravity.BOTTOM);
        header.setPadding(dp(8), 0, dp(8), dp(22));
        content.addView(header, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, headerH));

        TextView title = new TextView(this);
        title.setText("Mahmoud UI");
        title.setTextColor(textPrimary);
        title.setTextSize(34);
        title.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        title.setIncludeFontPadding(false);
        header.addView(title, matchWrap());

        TextView subtitle = new TextView(this);
        subtitle.setText("تحكم بقوة تمويه مركز التحكم الأصلي");
        subtitle.setTextColor(textSecondary);
        subtitle.setTextSize(15);
        subtitle.setPadding(0, dp(8), 0, 0);
        header.addView(subtitle, matchWrap());

        // ---- card 1: blur strength
        LinearLayout strengthCard = newCard();
        TextView label = new TextView(this);
        label.setText("قوة التمويه");
        label.setTextColor(textPrimary);
        label.setTextSize(17);
        label.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        strengthCard.addView(label, matchWrap());

        // slider + counter are kept LTR so the fill direction is predictable
        LinearLayout controls = new LinearLayout(this);
        controls.setOrientation(LinearLayout.VERTICAL);
        controls.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);

        LinearLayout counterRow = new LinearLayout(this);
        counterRow.setOrientation(LinearLayout.HORIZONTAL);
        counterRow.setGravity(Gravity.CENTER_VERTICAL);
        counterRow.addView(stepper("\u2212", "تقليل", -1), new LinearLayout.LayoutParams(dp(48), dp(48)));

        valueLabel = new TextView(this);
        valueLabel.setTextColor(textPrimary);
        valueLabel.setTextSize(56);
        valueLabel.setGravity(Gravity.CENTER);
        valueLabel.setIncludeFontPadding(false);
        valueLabel.setTypeface(Typeface.create("sans-serif-light", Typeface.NORMAL));
        counterRow.addView(valueLabel, new LinearLayout.LayoutParams(0,
                LinearLayout.LayoutParams.WRAP_CONTENT, 1f));

        counterRow.addView(stepper("+", "زيادة", 1), new LinearLayout.LayoutParams(dp(48), dp(48)));
        LinearLayout.LayoutParams counterLp = matchWrap();
        counterLp.topMargin = dp(10);
        controls.addView(counterRow, counterLp);

        strengthBar = new SeekBar(this);
        strengthBar.setMax(MAX_STRENGTH);
        styleSeekBar(strengthBar);
        LinearLayout.LayoutParams barLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(48));
        barLp.topMargin = dp(14);
        controls.addView(strengthBar, barLp);

        LinearLayout ends = new LinearLayout(this);
        ends.setOrientation(LinearLayout.HORIZONTAL);
        ends.setPadding(dp(6), 0, dp(6), 0);
        TextView less = endpoint("أضعف", Gravity.START);
        TextView more = endpoint("أقوى", Gravity.END);
        ends.addView(less, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        ends.addView(more, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        controls.addView(ends, matchWrap());
        strengthCard.addView(controls, matchWrap());

        // presets
        LinearLayout presets = new LinearLayout(this);
        presets.setOrientation(LinearLayout.HORIZONTAL);
        String[] names = {"خفيف", "متوسط", "أقصى"};
        for (int i = 0; i < 3; i++) {
            TextView chip = new TextView(this);
            chip.setText(names[i] + "\n" + chipValues[i] + "٪");
            chip.setTextSize(13);
            chip.setGravity(Gravity.CENTER);
            chip.setClickable(true);
            final int target = chipValues[i];
            chip.setOnClickListener(v -> {
                setStrength(target);
                schedulePersist();
            });
            chips[i] = chip;
            LinearLayout.LayoutParams chipLp = new LinearLayout.LayoutParams(0, dp(56), 1f);
            chipLp.leftMargin = dp(4);
            chipLp.rightMargin = dp(4);
            presets.addView(chip, chipLp);
        }
        LinearLayout.LayoutParams presetsLp = matchWrap();
        presetsLp.topMargin = dp(20);
        strengthCard.addView(presets, presetsLp);
        content.addView(strengthCard, cardLp());

        // ---- card 2: status + info rows
        LinearLayout infoCard = newCard();

        LinearLayout statusRow = new LinearLayout(this);
        statusRow.setOrientation(LinearLayout.HORIZONTAL);
        statusRow.setGravity(Gravity.CENTER_VERTICAL);
        statusDot = new View(this);
        LinearLayout.LayoutParams dotLp = new LinearLayout.LayoutParams(dp(10), dp(10));
        dotLp.setMarginEnd(dp(14));
        statusRow.addView(statusDot, dotLp);
        LinearLayout statusCol = new LinearLayout(this);
        statusCol.setOrientation(LinearLayout.VERTICAL);
        statusCol.addView(rowTitle("الحفظ بصلاحية الروت"), matchWrap());
        statusText = rowBody("");
        statusCol.addView(statusText, matchWrap());
        statusRow.addView(statusCol, new LinearLayout.LayoutParams(0,
                LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        infoCard.addView(statusRow, matchWrap());

        View line = new View(this);
        line.setBackgroundColor(divider);
        LinearLayout.LayoutParams lineLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, Math.max(1, dp(1)));
        lineLp.topMargin = dp(16);
        lineLp.bottomMargin = dp(16);
        infoCard.addView(line, lineLp);

        infoCard.addView(rowTitle("عن المستويات"), matchWrap());
        infoCard.addView(rowBody("التحكم من 1٪ إلى 100٪؛ كلما زادت القيمة زادت قوة البلور. القيمة نفسها للدارك واللايت."),
                matchWrap());
        content.addView(infoCard, cardLp());

        strengthBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar bar, int progress, boolean fromUser) {
                int value = clamp(progress);
                if (fromUser && value != pendingValue && value % 5 == 0) {
                    bar.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK);
                }
                pendingValue = value;
                updateLabel(value);
                // Do not spawn root prompts or writes while the thumb is moving.
            }

            @Override
            public void onStartTrackingTouch(SeekBar bar) {
                handler.removeCallbacks(persistRunnable);
            }

            @Override
            public void onStopTrackingTouch(SeekBar bar) {
                handler.removeCallbacks(persistRunnable);
                persist(pendingValue);
            }
        });

        setContentView(scroll);
        setStatus(STATUS_IDLE, "سيطلب التطبيق صلاحية الروت عند حفظ المستوى");
        refreshValue();
    }

    private void styleSeekBar(SeekBar bar) {
        int trackH = dp(14);

        GradientDrawable trackBg = round(track, trackH / 2f);
        GradientDrawable trackFill = round(accent, trackH / 2f);
        ClipDrawable clip = new ClipDrawable(trackFill, Gravity.START, ClipDrawable.HORIZONTAL);
        LayerDrawable layers = new LayerDrawable(new Drawable[]{trackBg, clip});
        layers.setId(0, android.R.id.background);
        layers.setId(1, android.R.id.progress);
        for (int i = 0; i < 2; i++) {
            layers.setLayerGravity(i, Gravity.CENTER_VERTICAL);
            layers.setLayerHeight(i, trackH);
        }
        bar.setProgressDrawable(layers);

        int thumbSize = dp(30);
        GradientDrawable shadow = new GradientDrawable();
        shadow.setShape(GradientDrawable.OVAL);
        shadow.setColor(dark ? 0x66000000 : 0x2A000000);
        shadow.setSize(thumbSize, thumbSize);
        GradientDrawable face = new GradientDrawable();
        face.setShape(GradientDrawable.OVAL);
        face.setColor(Color.WHITE);
        face.setSize(thumbSize, thumbSize);
        LayerDrawable thumb = new LayerDrawable(new Drawable[]{shadow, face});
        thumb.setLayerInset(1, dp(2), dp(1), dp(2), dp(3));
        bar.setThumb(thumb);
        bar.setThumbOffset(0);
        bar.setSplitTrack(false);
        bar.setBackground(null);
        bar.setPadding(dp(17), 0, dp(17), 0);
    }

    private LinearLayout newCard() {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(22), dp(22), dp(22), dp(22));
        card.setBackground(round(this.card, dp(28)));
        return card;
    }

    private LinearLayout.LayoutParams cardLp() {
        LinearLayout.LayoutParams lp = matchWrap();
        lp.bottomMargin = dp(12);
        return lp;
    }

    private TextView rowTitle(String text) {
        TextView view = new TextView(this);
        view.setText(text);
        view.setTextColor(textPrimary);
        view.setTextSize(16);
        view.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        return view;
    }

    private TextView rowBody(String text) {
        TextView view = new TextView(this);
        view.setText(text);
        view.setTextColor(textSecondary);
        view.setTextSize(14);
        view.setLineSpacing(0f, 1.15f);
        view.setPadding(0, dp(4), 0, 0);
        return view;
    }

    private TextView endpoint(String text, int gravity) {
        TextView view = new TextView(this);
        view.setText(text);
        view.setTextColor(textSecondary);
        view.setTextSize(13);
        view.setGravity(gravity | Gravity.CENTER_VERTICAL);
        return view;
    }

    private TextView stepper(String symbol, String description, int delta) {
        TextView button = new TextView(this);
        button.setText(symbol);
        button.setTextSize(26);
        button.setGravity(Gravity.CENTER);
        button.setTextColor(textPrimary);
        button.setIncludeFontPadding(false);
        button.setTypeface(Typeface.create("sans-serif-light", Typeface.NORMAL));
        button.setBackground(ripple(chipBg, dp(24)));
        button.setContentDescription(description);
        button.setClickable(true);
        button.setOnTouchListener(new StepTouch(delta));
        return button;
    }

    /** Tap for +/-1, hold to repeat; the value is saved shortly after the finger lifts. */
    private final class StepTouch implements View.OnTouchListener {
        private final int delta;
        private final Runnable repeat = new Runnable() {
            @Override
            public void run() {
                setStrength(pendingValue + delta);
                handler.postDelayed(this, 70);
            }
        };

        StepTouch(int delta) {
            this.delta = delta;
        }

        @Override
        public boolean onTouch(View view, MotionEvent event) {
            switch (event.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    setStrength(pendingValue + delta);
                    handler.postDelayed(repeat, 420);
                    break;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    handler.removeCallbacks(repeat);
                    schedulePersist();
                    break;
                default:
                    break;
            }
            return false; // let the view run its own pressed/ripple handling
        }
    }

    // ------------------------------------------------------------------ logic

    private void refreshValue() {
        if (strengthBar == null) return;
        strengthBar.setEnabled(true);
        int current = clamp(Settings.System.getInt(getContentResolver(), KEY, DEFAULT_STRENGTH));
        pendingValue = current;
        strengthBar.setProgress(current);
        updateLabel(current);
    }

    private void setStrength(int requested) {
        int value = clamp(requested);
        if (value != pendingValue) {
            strengthBar.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK);
        }
        pendingValue = value;
        strengthBar.setProgress(value);
        updateLabel(value);
    }

    private void schedulePersist() {
        handler.removeCallbacks(persistRunnable);
        handler.postDelayed(persistRunnable, 450);
    }

    private void persist(int value) {
        final int requested = clamp(value);
        setStatus(STATUS_BUSY, "جارٍ حفظ مستوى البلور — وافق على طلب الروت إذا ظهر");
        saver.execute(() -> {
            boolean saved = RootSettings.writeAndVerify(requested);
            runOnUiThread(() -> {
                if (saved) {
                    setStatus(STATUS_OK, "تم حفظ المستوى: " + requested + "٪؛ أعد فتح مركز التحكم");
                } else {
                    setStatus(STATUS_ERROR, "فشل الحفظ؛ تحقق من موافقة مدير الروت على Mahmoud UI");
                    Toast.makeText(MainActivity.this, "تعذر حفظ مستوى البلور بصلاحية الروت",
                            Toast.LENGTH_LONG).show();
                }
            });
        });
    }

    private void setStatus(int type, String text) {
        if (statusText == null || statusDot == null) return;
        int color;
        switch (type) {
            case STATUS_OK: color = green; break;
            case STATUS_ERROR: color = red; break;
            case STATUS_BUSY: color = accent; break;
            default: color = textSecondary; break;
        }
        GradientDrawable dot = new GradientDrawable();
        dot.setShape(GradientDrawable.OVAL);
        dot.setColor(color);
        statusDot.setBackground(dot);
        statusText.setText(text);
    }

    private void updateLabel(int value) {
        if (valueLabel != null) {
            String number = Integer.toString(value);
            SpannableString text = new SpannableString(number + "٪");
            text.setSpan(new RelativeSizeSpan(0.4f), number.length(), text.length(),
                    Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            valueLabel.setText(text);
        }
        for (int i = 0; i < chips.length; i++) {
            if (chips[i] == null) continue;
            boolean selected = chipValues[i] == value;
            if (selected == chipSelected[i] && chips[i].getBackground() != null) continue;
            chipSelected[i] = selected;
            chips[i].setBackground(ripple(selected ? accentSoft : chipBg, dp(28)));
            chips[i].setTextColor(selected ? accent : textPrimary);
            chips[i].setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        }
    }

    private int clamp(int value) {
        return Math.max(1, Math.min(MAX_STRENGTH, value));
    }

    // ---------------------------------------------------------------- helpers

    private GradientDrawable round(int color, float radiusPx) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(color);
        drawable.setCornerRadius(radiusPx);
        return drawable;
    }

    private Drawable ripple(int fill, float radiusPx) {
        ColorStateList rippleColor = ColorStateList.valueOf(dark ? 0x33FFFFFF : 0x1F000000);
        return new RippleDrawable(rippleColor, round(fill, radiusPx), round(Color.WHITE, radiusPx));
    }

    private LinearLayout.LayoutParams matchWrap() {
        return new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
    }

    private int dp(float value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }
}
