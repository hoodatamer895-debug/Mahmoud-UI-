package dev.mahmuod.ui;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.concurrent.TimeUnit;

final class RootSettings {
    private static final String KEY = "mahmuod_ui_blur_strength_v2";

    private RootSettings() { }

    static boolean writeAndVerify(int value) {
        int safeValue = Math.max(1, Math.min(100, value));
        String command = "settings put system " + KEY + " " + safeValue
                + " && settings get system " + KEY;
        Process process = null;
        try {
            process = new ProcessBuilder("su", "-c", command)
                    .redirectErrorStream(true)
                    .start();
            boolean finished = process.waitFor(60, TimeUnit.SECONDS);
            if (!finished) {
                process.destroyForcibly();
                return false;
            }
            int exitCode = process.exitValue();
            String output;
            try (BufferedReader reader = new BufferedReader(
                    new InputStreamReader(process.getInputStream()))) {
                StringBuilder text = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) text.append(line.trim()).append('\n');
                output = text.toString().trim();
            }
            if (exitCode != 0 || output.isEmpty()) return false;
            String[] lines = output.split("\\R");
            return Integer.toString(safeValue).equals(lines[lines.length - 1].trim());
        } catch (Throwable error) {
            if (process != null) process.destroyForcibly();
            return false;
        }
    }
}
